module.exports = Object.assign
